from django.apps import AppConfig


class AlumnoappConfig(AppConfig):
    name = 'alumnoapp'
